from django.contrib import admin
from django.urls import path
from django.http import HttpResponse

def home(request):
    return HttpResponse("<h1>УРА! РАБОТАЕТ!</h1><p>Если вы это видите, Django работает правильно.</p>")

urlpatterns = [
    path('admin/', admin.site.urls),
    path('', home),
]